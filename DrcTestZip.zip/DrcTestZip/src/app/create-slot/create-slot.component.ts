import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-create-slot',
  templateUrl: './create-slot.component.html',
  styleUrls: ['./create-slot.component.css'],
})
export class CreateSlotComponent {
  createSlot: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.createForm();
  }

  // Initializes the form
  createForm() {
    this.createSlot = this.formBuilder.group({
      slotNumber: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
    });
  }

  get createSlotFormControl() {
    return this.createSlot.controls;
  }

  // Function to create the slot
  onSubmit(formData) {
    if (this.createSlot.valid) {
      let createdSlots = localStorage.getItem('createdSlots')
        ? JSON.parse(localStorage.getItem('createdSlots'))
        : [];

      if (!createdSlots.includes(parseInt(formData.slotNumber))) {
        createdSlots.push(parseInt(formData.slotNumber));
        localStorage.setItem('createdSlots', JSON.stringify(createdSlots));
        this.toastr.success('Slot has been created successfully!!');
      } else {
        this.toastr.error('Slot already added.Please add another slot');
      }
    }
  }

  // Function to clear the slot
  clearSlot(formData) {
    if (this.createSlot.valid) {
      let createdSlots = localStorage.getItem('createdSlots')
        ? JSON.parse(localStorage.getItem('createdSlots'))
        : [];
      if (createdSlots.includes(parseInt(formData.slotNumber))) {
        const index = createdSlots.indexOf(parseInt(formData.slotNumber));
        if (index > -1) {
          createdSlots.splice(index, 1);
        }
        localStorage.setItem('createdSlots', JSON.stringify(createdSlots));
        this.toastr.success('Slot has been removed successfully!!');
      } else {
        this.toastr.error('Entered slot does not exist!!');
      }
    }
  }
}
