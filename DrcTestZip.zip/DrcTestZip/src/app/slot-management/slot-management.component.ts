import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-slot-management',
  templateUrl: './slot-management.component.html',
  styleUrls: ['./slot-management.component.css'],
})
export class SlotManagementComponent implements OnInit {
  manageSlots: FormGroup;
  carsParkedData = [];
  constructor(
    private formBuilder: FormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.createForm();
    this.getParkedData();
  }

  // Function to get the parked data
  getParkedData() {
    this.carsParkedData = localStorage.getItem('parkedData')
      ? JSON.parse(localStorage.getItem('parkedData'))
      : [];
  }

  createForm() {
    this.manageSlots = this.formBuilder.group({
      carRegistrationNumber: ['', [Validators.required]],
      carColor: ['', [Validators.required]],
    });
  }

  get createSlotFormControl() {
    return this.manageSlots.controls;
  }

  onSubmit(formData) {
    if (this.manageSlots.valid) {
      let parkedData: any = localStorage.getItem('parkedData')
        ? JSON.parse(localStorage.getItem('parkedData'))
        : [];

      let freeSlots =
        localStorage.getItem('freeSlots') !== null
          ? JSON.parse(localStorage.getItem('freeSlots'))
          : JSON.parse(localStorage.getItem('createdSlots'));

      if (!freeSlots || (freeSlots && freeSlots.length === 0)) {
        this.toastr.error(
          'There is no slot free right now.Please wait until slot available!!'
        );
        return;
      }

      freeSlots.sort((a, b) => a - b);

      const parkedDataObject = {
        registrationNumber: formData.carRegistrationNumber,
        color: formData.carColor,
        assignedSlot: freeSlots[0],
      };
      parkedData.push(parkedDataObject);
      this.carsParkedData = [...parkedData];
      localStorage.setItem('parkedData', JSON.stringify(parkedData));
      freeSlots.shift();
      localStorage.setItem('freeSlots', JSON.stringify(freeSlots));
      this.toastr.success('Car has been parked!!');
      this.manageSlots.reset();
    }
  }
}
