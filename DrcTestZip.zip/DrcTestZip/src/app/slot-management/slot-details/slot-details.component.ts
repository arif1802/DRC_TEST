import { parkedDetails } from './../../interfaces/parked-details';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-slot-details',
  templateUrl: './slot-details.component.html',
  styleUrls: ['./slot-details.component.css'],
})
export class SlotDetailsComponent implements OnInit {
  displayedColumns: string[] = [
    'id',
    'carRegistrationNumber',
    'carColor',
    'slot',
    'action',
  ];
  dataSource: MatTableDataSource<any>;
  @Input() carsParkedData;
  copyCarsParkedData = [];
  createdSlots = [];
  cities = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  constructor(private toastr: ToastrService) {}

  ngOnInit(): void {
    this.getParkedData();
    this.getSlotNumbers();
    this.getCities();
    this.initializeFilter();
  }

  // Function to initialize filter
  initializeFilter() {
    this.dataSource.filterPredicate = function (data, filter: string): boolean {
      return (
        data.registrationNumber.toLowerCase().includes(filter) ||
        data.color.toLowerCase().includes(filter) ||
        data.assignedSlot === filter
      );
    };
  }

  ngOnChanges(): void {
    if (this.dataSource) {
      this.dataSource.data = this.carsParkedData;
    }
    this.copyCarsParkedData = [...this.carsParkedData];
  }

  // Function to get the slot numbers
  getSlotNumbers() {
    if (localStorage.getItem('createdSlots')) {
      this.createdSlots = JSON.parse(localStorage.getItem('createdSlots'));
    }
  }

  // Function to get the details of parked cars
  getParkedData() {
    this.dataSource = new MatTableDataSource(this.carsParkedData);
  }

  // Function to truncate first 4 digit from the registration number
  getCities() {
    this.copyCarsParkedData.filter((item) => {
      this.cities.push(item.registrationNumber.slice(0, 4));
    });
  }

  // Function for filtering data
  applyFilter(filterValue: string, column) {
    if (column !== 'slot') {
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    }
    this.dataSource.filter = filterValue;
  }

  // Function to remove car from parking
  removeCarFromParking(index, rowData) {
    if (rowData.assignedSlot) {
      this.carsParkedData.splice(index, 1);
      this.dataSource.data = this.carsParkedData;

      let freeSlots = JSON.parse(localStorage.getItem('freeSlots'));
      freeSlots.push(rowData.assignedSlot);
      localStorage.setItem('freeSlots', JSON.stringify(freeSlots));

      localStorage.setItem('parkedData', JSON.stringify(this.carsParkedData));
      this.toastr.error('Cars has been successfully unpark from the parking!!');
    }
  }
}
