import { SlotManagementComponent } from './slot-management/slot-management.component';
import { CreateSlotComponent } from './create-slot/create-slot.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/create-slot', pathMatch: 'full' },
  {
    path: 'create-slot',
    component: CreateSlotComponent,
  },
  {
    path: 'manage-slots',
    component: SlotManagementComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
