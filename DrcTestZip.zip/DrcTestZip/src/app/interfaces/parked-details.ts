export interface parkedDetails {
  id: number;
  carRegistrationNumber: string;
  carColor: string;
  slot: any;
}
